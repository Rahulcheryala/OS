#include <iostream>
#include <vector>
#include <set>
#include <unordered_map>
#include <queue>
#include <algorithm>
#include <time.h>

using namespace std;

int main( int argc, char** argv )
{
    int PAGES = atoi(argv[1]);
    int FRAMES = atoi(argv[2]);
    int SWAPSPACE = atoi(argv[3]);

    cout << "Number of Pages : " << PAGES << endl;
    cout << "Number of Frames : " << FRAMES << endl;
    cout << "Number of SwapSpaces : " << SWAPSPACE << endl;

    // vector<int> AddressSpace(PAGES);
    // vector<int> MainMemory(FRAMES);
    vector<int> SwapSpace;

    vector<int> MainMemory;

    // int AddressSpaceSize = 0;
    int Frame = 0;     // Frame Number
    int SwapSpaceSize = 0;

    vector<int> Dat;

    set<int> Pages;     // To Store number of unique pages. And to check whether it is less than Memory + SwapSpace or not.

    unordered_map<int, int> PageTable;

    int PageFaults = 0;

    FILE *input = fopen( argv[4], "r" );

    int dat;

    while( fscanf(input, "%d", &dat) != EOF )
    {
        Dat.push_back(dat);
        Pages.insert(dat);
    }

    cout << "Number of Unique Pages : " << Pages.size() << endl << endl;

    for( int page : Dat )
    {
        if( PageTable.find(page) == PageTable.end() )   // Page Not Found ==> Page Fault
        {
            // cout << "For page : " << page << " ";
            PageFaults++;
            // cout << "Page Faults : " << PageFaults << endl;

            if( Frame < FRAMES )
            {
                PageTable[page] = Frame % FRAMES;
                
                // for( auto page : PageTable )
                // {
                //     cout << page.first << " -> " << page.second << endl;
                // }

                // MainMemory[Frame] = page;
                Frame++;
                MainMemory.push_back(page);
            }
            else        // Memory already full. Need to swap disks with Swap Space.
            {
                srand(time(0));
                int RandomIndex=rand() % FRAMES;
                // cout << "RamdonIndex = " << RandomIndex << endl;
                int oldpage = MainMemory[RandomIndex];
                int newpage = page;
                MainMemory.erase(MainMemory.begin() + RandomIndex);

                if( SwapSpaceSize < SWAPSPACE )
                {
                    // cout << "SwapSpace not filled in yet" << endl;
                    // cout << "IF : Old : " << oldpage << " New : " << newpage << endl;

                    // cout << "Before -> SwapSpaceSize : " << SwapSpaceSize << endl;

                    // for( int i=0; i<SwapSpace.size(); i++ )
                    // {
                    //     cout << "SwapSpace[" << i << "] = " << SwapSpace[i] << endl;
                    // }

                    // cout << endl << endl;

                    int it;  // Get the position of page in SwapSpace
                    bool flag = false;

                    for( int i=0; i<SwapSpace.size(); i++ )
                    {
                        if( SwapSpace[i] == page )
                        {
                            it = i;
                            flag = true;
                            break;
                        }
                    }

                    if( flag == false )
                    {
                        it = -1;
                    }

                    if( it == -1 ) // The page not yet present in Swap Space.
                    {
                        // cout << "Page not found in partially filled in SwapSpace" << endl;
                        // cout << "IF IF : Old : " << oldpage << " New : " << newpage << endl;

                        // cout << "Before -> SwapSpaceSize : " << SwapSpaceSize << endl;

                        // for( int i=0; i<SwapSpace.size(); i++ )
                        // {
                        //     cout << "SwapSpace[" << i << "] = " << SwapSpace[i] << endl;
                        // }

                        // cout << endl << endl;

                        SwapSpace.push_back(oldpage);       // Add the page in SwapSpace
                        SwapSpaceSize++;                    // Increment the size
                        int oldframe = PageTable[oldpage];  // Get the old frame which old page maps to
                        PageTable.erase(oldpage);           // Erase the page from page table
                        PageTable[newpage] = oldframe;      // Make the new page points to same old frame
                        // MainMemory[oldframe] = newpage;     // Replace the old page with new page
                        MainMemory.push_back(newpage);      // Push new page into MainMemory

                        // cout << "IF" << endl;
                        // for( auto page : PageTable )
                        // {
                        //     cout << page.first << " -> " << page.second << endl;
                        // }

                        // cout << "After -> SwapSpaceSize : " << SwapSpaceSize << endl;

                        // for( int i=0; i<SwapSpace.size(); i++ )
                        // {
                        //     cout << "SwapSpace[" << i << "] = " << SwapSpace[i] << endl;
                        // }

                        // cout << "Page has been added to partially filled SwapSpace" << endl;
                        // cout << endl << endl;
                    }
                    else
                    {
                        // cout << "Page has been found in partial SwapSpace" << endl;
                        // cout << "ELSE ELSE : Old : " << oldpage << " New : " << newpage << endl;

                        // cout << "Before -> SwapSpaceSize : " << SwapSpaceSize << endl;

                        // for( int i=0; i<SwapSpace.size(); i++ )
                        // {
                        //     cout << "SwapSpace[" << i << "] = " << SwapSpace[i] << endl;
                        // }

                        // cout << endl << endl;

                        SwapSpace.erase( SwapSpace.begin() + it ); // Replace the new page with the old page in SwapSpace
                        SwapSpace.push_back(oldpage);       // Add the old page in SwapSpace
                        int oldframe = PageTable[oldpage];  // Get the old frame which old page maps to
                        PageTable.erase(oldpage);           // Erase the page from page table
                        PageTable[newpage] = oldframe;      // Make the new page points to same old frame
                        // MainMemory[oldframe] = newpage;     // Replace the old page with new page
                        MainMemory.push_back(newpage);                 // Push new page into MainMemory

                        // cout << "ELSE" << endl;
                        // for( auto page : PageTable )
                        // {
                        //     cout << page.first << " -> " << page.second << endl;
                        // }

                        // cout << "After -> SwapSpaceSize : " << SwapSpaceSize << endl;

                        // for( int i=0; i<SwapSpace.size(); i++ )
                        // {
                        //     cout << "SwapSpace[" << i << "] = " << SwapSpace[i] << endl;
                        // }

                        // cout << "Page has been replaced" << endl << endl << endl;
                    }
                }
                else
                {
                    // cout << "SwapSpace is Full" << endl;
                    // cout << "ELSE : Old : " << oldpage << " New : " << newpage << endl;

                    // cout << "Before -> SwapSpaceSize : " << SwapSpaceSize << endl;

                    // for( int i=0; i<SwapSpace.size(); i++ )
                    // {
                    //     cout << "SwapSpace[" << i << "] = " << SwapSpace[i] << endl;
                    // }

                    // cout << endl << endl;

                    int it;  // Get the position of page in SwapSpace
                    bool flag = false;

                    for( int i=0; i<SWAPSPACE; i++ )
                    {
                        if( SwapSpace[i] == page )
                        {
                            it = i;
                            flag = true;
                            break;
                        }
                    }

                    if( flag == false )
                    {
                        it = -1;
                    }

                    // cout << "it = " << it << endl;

                    if( it == -1 )
                    {
                        cout << "Using more number pages than CPU can handle. #Pages > MainMemory + SwapSpace" << endl;
                        exit(0);
                    }

                    SwapSpace.erase( SwapSpace.begin() + it ); // Replace the new page with the old page in SwapSpace
                    SwapSpace.push_back(oldpage);       // Add the old page in SwapSpace
                    int oldframe = PageTable[oldpage];  // Get the old frame which old page maps to
                    PageTable.erase(oldpage);           // Erase the page from page table
                    PageTable[newpage] = oldframe;      // Make the new page points to same old frame
                    // MainMemory[oldframe] = newpage;     // Replace the old page with new page
                    MainMemory.push_back(newpage);                 // Push new page into MainMemory

                    // cout << "ELSE ELSE" << endl;
                    // for( auto page : PageTable )
                    // {
                    //     cout << page.first << " -> " << page.second << endl;
                    // }

                    // cout << "After -> SwapSpaceSize : " << SwapSpaceSize << endl;

                    // for( int i=0; i<SwapSpace.size(); i++ )
                    // {
                    //     cout << "SwapSpace[" << i << "] = " << SwapSpace[i] << endl;
                    // }

                    // cout << "Page has been replaced" << endl << endl << endl;
                }
            }
        }
        else
        {
            // cout << "Found page : " << page << endl;
        }
    }

    cout << "Page Faults : " << PageFaults << endl;

    // cout << PageFaults << " " << FRAMES << endl;
}