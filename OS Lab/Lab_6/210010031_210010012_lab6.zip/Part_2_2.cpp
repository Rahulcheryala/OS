// #include <iostream>
#include <bits/stdc++.h>
#include <vector>
#include <thread>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <fcntl.h>

using namespace std;

sem_t s;

key_t key = getpid();

char type[30];
int Height;
int Width;
int max_pixel;

struct Pixel
{
    int red;
    int green;
    int blue;
};

void RGB_TO_GRAYSCALE()
{
    int shmid = shmget( key, sizeof( struct Pixel ) * Height * Width, 0666 );
    struct Pixel *SharedData = ( struct Pixel *) shmat( shmid, NULL, 0 );

    for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
		{
            sem_wait( &s );

			int ntsc = (0.299 * SharedData[ ( i * Width ) + j ].red) + (0.587 * SharedData[ ( i * Width ) + j ].green) + (0.114 * SharedData[ ( i * Width ) + j ].blue);

			SharedData[ ( i * Width ) + j ].red   = ntsc;
			SharedData[ ( i * Width ) + j ].green = ntsc;
			SharedData[ ( i * Width ) + j ].blue  = ntsc;

            sem_post( &s );
		}
	}
}

void CONTRAST_ADJUSTMENT()
{
    int shmid = shmget( key, sizeof( struct Pixel ) * Height * Width, 0666 );
    struct Pixel *SharedData = ( struct Pixel *) shmat( shmid, NULL, 0 );

    for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
		{
            sem_wait( &s );

			SharedData[ ( i * Width ) + j ].red = (SharedData[ ( i * Width ) + j ].red + 50) * 0.5;
			
			if( SharedData[ ( i * Width ) + j ].red > 255 )
				SharedData[ ( i * Width ) + j ].red = 255;
			
			SharedData[ ( i * Width ) + j ].green = (SharedData[ ( i * Width ) + j ].green + 50) * 0.5;
			
			if( SharedData[ ( i * Width ) + j ].green > 255 )
				SharedData[ ( i * Width ) + j ].green = 255;
			
			SharedData[ ( i * Width ) + j ].blue = (SharedData[ ( i * Width ) + j ].blue + 50) * 0.5;
			
			if( SharedData[ ( i * Width ) + j ].blue > 255 )
				SharedData[ ( i * Width ) + j ].blue = 255;

            sem_post( &s );		
		}
	}
}

int main( int argc, char** argv )
{
	FILE *input = fopen( argv[1], "r" );

	fscanf( input, "%s", type );
    fscanf( input, "%d %d", &Width, &Height );
	fscanf( input, "%d", &max_pixel );

    struct Pixel *SharedData;
    struct Pixel Image;

    int shmid = shmget( key, sizeof( struct Pixel ) * Height * Width, 0666 | IPC_CREAT );
    SharedData = ( struct Pixel *) shmat( shmid, NULL, 0 );

    sem_init(&s, 0, 1);

	for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
		{
            int red;
            int green;
            int blue;

			fscanf( input, "%d", &red );
            fscanf( input, "%d", &green );
            fscanf( input, "%d", &blue );

            Image.red = red;
            Image.green = green;
            Image.blue = blue;

            SharedData[ ( i * Width ) + j ] = Image;
		}
	}

    pid_t PID = fork();

    if( PID == 0 )
        RGB_TO_GRAYSCALE();
    else
    {
        wait(NULL);
        
        CONTRAST_ADJUSTMENT();

        FILE *output = fopen( argv[2], "w" );
        
        fprintf( output, "%s\n", type );
        fprintf( output, "%d %d\n", Width, Height );
        fprintf( output, "%d\n", 255 );

        for( int i=0; i<Height; i++ )
        {
            for( int j=0; j<Width; j++ )
            {
                Image = SharedData[ ( i * Width ) + j ];

                fprintf( output, "%d %d %d ", Image.red, Image.green, Image.blue );
            }

            fprintf( output, "\n" );
        }
    }
}
