// #include <iostream>
#include <bits/stdc++.h>
#include <vector>
#include <thread>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <fcntl.h>

using namespace std;

int channel[2];

char type[30];
int Height;
int Width;
int max_pixel;

void RGB_TO_GRAYSCALE( vector<vector<int>> &red, vector<vector<int>> &green, vector<vector<int>> &blue )
{
    for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
		{
			int ntsc = (0.299 * red[i][j]) + (0.587 * green[i][j]) + (0.114 * blue[i][j]);

			red[i][j] = ntsc;
			green[i][j]= ntsc;
			blue[i][j] = ntsc;

            write( channel[1], &red[i][j],   sizeof(int) );
            write( channel[1], &green[i][j], sizeof(int) );
            write( channel[1], &blue[i][j],  sizeof(int) );
		}
	}

    close( channel[1] );
}

void EDGE_DETECTION( vector<vector<int>> &red, vector<vector<int>> &green, vector<vector<int>> &blue )
{
    for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
		{
            int Red;
            int Green;
            int Blue;

            read( channel[0], &Red,   sizeof(int) );
            read( channel[0], &Green, sizeof(int) );
            read( channel[0], &Blue,  sizeof(int) );

			red[i][j] = (Red + 50) * 0.5;
			
			if( red[i][j] > 255 )
				red[i][j] = 255;
			
			green[i][j] = (Green + 50) * 0.5;
			
			if( green[i][j] > 255 )
				green[i][j] = 255;
			
			blue[i][j] = (Blue + 50) * 0.5;
			
			if( blue[i][j] > 255 )
				blue[i][j] = 255;	
		}
	}
}

int main( int argc, char** argv )
{
	FILE *input = fopen( argv[1], "r" );

	fscanf( input, "%s", type );
    fscanf( input, "%d %d", &Width, &Height );
	fscanf( input, "%d", &max_pixel );

	vector<vector<int>> red(Height, vector<int> (Width));
	vector<vector<int>> green(Height, vector<int> (Width));
	vector<vector<int>> blue(Height, vector<int> (Width));

	for( int i=0; i<Height; i++ )
		for( int j=0; j<Width; j++ )
			fscanf( input, "%d%d%d", &red[i][j], &green[i][j], &green[i][j] );

    pipe(channel);

    pid_t PID = fork();

    if( PID == 0 )
    {
        close( channel[0] );
        RGB_TO_GRAYSCALE( red, green, blue );
    }
    else
    {
        close( channel[1] );
        EDGE_DETECTION( red, green, blue );

        wait(NULL);

        FILE *output = fopen( argv[2], "w" );
        
        fprintf( output, "%s\n", type );
        fprintf( output, "%d %d\n", Width, Height );
        fprintf( output, "%d\n", 255 );

        for( int i=0; i<Height; i++ )
        {
            for( int j=0; j<Width; j++ )
                fprintf( output, "%d %d %d ", red[i][j], green[i][j], blue[i][j] );

            fprintf( output, "\n" );
        }
    }
}