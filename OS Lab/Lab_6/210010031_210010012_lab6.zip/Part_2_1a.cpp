// #include <iostream>
#include <bits/stdc++.h>
#include <vector>
#include <thread>

using namespace std;

atomic_flag Flag = ATOMIC_FLAG_INIT;

char type[30];
int Height;
int Width;
int Max_pixel;

void RGB_TO_GRAYSCALE( vector<vector<int>> &Red, vector<vector<int>> &Green, vector<vector<int>> &Blue )
{
    for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
		{
            while( atomic_flag_test_and_set( &Flag ) );

			int ntsc = (0.299 * Red[i][j]) + (0.587 * Green[i][j]) + (0.114 * Blue[i][j]);

			Red[i][j] = ntsc;
			Green[i][j]= ntsc;
			Blue[i][j] = ntsc;

            atomic_flag_clear( &Flag );
		}
	}
}

void CONTRAST_ADJUSTMENT( vector<vector<int>> &Red, vector<vector<int>> &Green, vector<vector<int>> &Blue )
{
    for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
		{
            while( atomic_flag_test_and_set( &Flag ) );

			Red[i][j] = (Red[i][j] + 50) * 0.5;
			
			if( Red[i][j] > 255 )
				Red[i][j] = 255;
			
			Green[i][j] = (Green[i][j] + 50) * 0.5;
			
			if( Green[i][j] > 255 )
				Green[i][j] = 255;
			
			Blue[i][j] = (Blue[i][j] + 50) * 0.5;
			
			if( Blue[i][j] > 255 )
				Blue[i][j] = 255;

            atomic_flag_clear( &Flag );			
		}
	}
}

int main( int argc, char** argv )
{
	FILE *Input = fopen( argv[1], "r" );

	fscanf( Input, "%s", type );
    fscanf( Input, "%d %d", &Width, &Height );
	fscanf( Input, "%d", &Max_pixel );

	vector<vector<int>> Red(Height, vector<int> (Width));
	vector<vector<int>> Green(Height, vector<int> (Width));
	vector<vector<int>> Blue(Height, vector<int> (Width));

	for( int i=0; i<Height; i++ )
		for( int j=0; j<Width; j++ )
			fscanf( Input, "%d%d%d", &Red[i][j], &Green[i][j], &Green[i][j] );

    thread T1 ( RGB_TO_GRAYSCALE, std::ref(Red), std::ref(Green), std::ref(Blue) );
    T1.join();

    thread T2 ( CONTRAST_ADJUSTMENT,   std::ref(Red), std::ref(Green), std::ref(Blue) );
    T2.join();

	FILE *Output = fopen( argv[2], "w" );
	
	fprintf( Output, "%s\n", type );
	fprintf( Output, "%d %d\n", Width, Height );
	fprintf( Output, "%d\n", Max_pixel );

	for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
			fprintf( Output, "%d %d %d ", Red[i][j], Green[i][j], Blue[i][j] );

		fprintf( Output, "\n" );
	}
}