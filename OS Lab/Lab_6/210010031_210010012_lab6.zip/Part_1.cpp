#include <iostream>
#include <vector>

using namespace std;

char type[30];
int Height;
int Width;
int Max_pixel;

int main( int argc, char** argv )
{
	FILE *Input = fopen( argv[1], "r" );
	
	fscanf( Input, "%s", type );
	fscanf( Input, "%d %d", &Width, &Height );
	fscanf( Input, "%d", &Max_pixel );

	vector<vector<int>> Red(Height, vector<int> (Width));
	vector<vector<int>> Green(Height, vector<int> (Width));
	vector<vector<int>> Blue(Height, vector<int> (Width));

	for( int i=0; i<Height; i++ )
		for( int j=0; j<Width; j++ )
			fscanf( Input, "%d%d%d", &Red[i][j], &Green[i][j], &Green[i][j] );

	/* RGB TO GRAY SCALE */

	for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
		{
			int ntsc = (0.299 * Red[i][j]) + (0.587 * Green[i][j]) + (0.114 * Blue[i][j]);

			Red[i][j] = ntsc;
			Green[i][j]= ntsc;
			Blue[i][j] = ntsc;
		}
	}

	/* CONTRAST ADJUSTMENT */

	for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
		{
			Red[i][j] = (Red[i][j] + 50) * 0.5;
			
			if( Red[i][j] > 255 )
				Red[i][j] = 255;
			
			Green[i][j] = (Green[i][j] + 50) * 0.5;
			
			if( Green[i][j] > 255 )
				Green[i][j] = 255;
			
			Blue[i][j] = (Blue[i][j] + 50) * 0.5;
			
			if( Blue[i][j] > 255 )
				Blue[i][j] = 255;
			
		}
	}

	FILE *Output = fopen( argv[2], "w" );
	
	fprintf( Output, "%s\n", type );
	fprintf( Output, "%d %d\n", Width, Height );
	fprintf( Output, "%d\n", Max_pixel );

	for( int i=0; i<Height; i++ )
	{
		for( int j=0; j<Width; j++ )
			fprintf( Output, "%d %d %d ", Red[i][j], Green[i][j], Blue[i][j] );

		fprintf( Output, "\n" );
	}
}
