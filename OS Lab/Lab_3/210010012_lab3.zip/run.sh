cp schedule.c /usr/src/minix/servers/sched/schedule.c
cd /usr/src && make build MKUPDATE=yes
exit 0