cp ./const.h /usr/src/minix/include/minix/
cp ./fslib.c /usr/src/minix/lib/libc/gen/
cp ./VFS/link.c /usr/src/minix/servers/vfs/
cp ./VFS/open.c /usr/src/minix/servers/vfs/
cp ./VFS/read.c /usr/src/minix/servers/vfs/
cp ./MFS/read.c /usr/src/minix/fs/mfs/
cp ./MFS/write.c /usr/src/minix/fs/mfs/
make build MKUPDATE=yes
